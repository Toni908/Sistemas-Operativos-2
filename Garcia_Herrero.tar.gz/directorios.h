//Antonio García Font y Maria Isabel Herrero Soteras  
#include "ficheros.h"
#include <sys/time.h> // no podemos usar el struct timeval del nivel9 sin incluir el systime

#define TAMNOMBRE 60 //tamaño del nombre de directorio o fichero, en Ext2 = 256
#define PROFUNDIDAD 32 //profundidad máxima del árbol de directorios

// lo definimos para imprimir en ls, define el tamaño de fila y el buffer de de la linea
#define TAMFILA 100
#define TAMBUFFER (TAMFILA*1000) //suponemos un máx de 1000 entradas

//Definimos los errores que puede haber
#define ERROR_CAMINO_INCORRECTO (-2)
#define ERROR_PERMISO_LECTURA (-3)
#define ERROR_NO_EXISTE_ENTRADA_CONSULTA (-4)
#define ERROR_NO_EXISTE_DIRECTORIO_INTERMEDIO (-5)
#define ERROR_PERMISO_ESCRITURA (-6)
#define ERROR_ENTRADA_YA_EXISTENTE (-7)
#define ERROR_NO_SE_PUEDE_CREAR_ENTRADA_EN_UN_FICHERO (-8)

#define USARCACHE 1 // 0: sin caché, 1: última L/E, 2: tabla FIFO, 3: tabla LRU
#define CACHE_SIZE 3 // tamaño de cache para usar con USARCACHE 2 o 3

struct entrada {
  char nombre[TAMNOMBRE];
  unsigned int ninodo;
};

struct UltimaEntrada {
   char camino[TAMNOMBRE * PROFUNDIDAD];
   int p_inodo;
   #if (USARCACHE == 3)
      struct timeval ultima_consulta;
   #endif
};

// Nivel 7
int extraer_camino(const char *camino, char *inicial, char *final, char *tipo);
int buscar_entrada(const char *camino_parcial, unsigned int *p_inodo_dir, unsigned int *p_inodo, unsigned int *p_entrada, char reservar, unsigned char permisos);
void mostrar_error_buscar_entrada(int error);
// Nivel 8
int mi_creat(const char *camino, unsigned char permisos);
int mi_dir(const char *camino, char *buffer, char tipo, char flag);
int mi_chmod(const char *camino, unsigned char permisos);
int mi_stat(const char *camino, struct STAT *p_stat);
// Nivel 9
int mi_write(const char *camino, const void *buf, unsigned int offset, unsigned int nbytes);
int mi_read(const char *camino, void *buf, unsigned int offset, unsigned int nbytes);
//Nivel 10
int mi_link(const char *camino1, const char *camino2);
int mi_unlink(const char *camino);